<?php
$title = "About";
$content = '
		
		<fieldset>
		<legend>On Monitoring</legend>
		<img src="Images/About/nrc.jpg" class="imgLeft" />
        <h3>Narayan Ranjan Chakraborty</h3>
        <p  align="justify">
           	Assistant Professor,Department of CSE,<br>Daffodil International University.<br><br>
           	Contact me : 01847-140023 <br>
			Webpage:<a href=" http://faculty.daffodilvarsity.edu.bd/profile/cse/narayan.html"> http://faculty.daffodilvarsity.edu.bd/profile/cse/narayan.html</a><br>
        	E-mail Address: <a href="mailto:narayan@daffodilvarsity.edu.bd"? subject="Information & Query">narayan@daffodilvarsity.edu.bd</a><br>
        	Follow on facebook: <a href="https://web.facebook.com/narayan633">Narayan Chakraborty</a> 
        </p>
		</fieldset>		
				
		<br>						
		
		<fieldset>
		<legend>On Developing</legend>		
				
			
        <img src="Images/About/ananta.jpg" class="imgLeft" />
        <h3>Ananta Chandra Bhowmik</h3>
        <p align="justify">
           	Hi.......I am Ananta Chandra Bhowmik, student of Daffodil International University.<br><br>
           	If case of any query please feel free to contact me : 01676656000 <br>
        	Mail me: <a href="mailto:ananta2086@diu.edu.bd"? subject="Information & Query">ananta2086@diu.edu.bd</a><br>
        	Become a friend on facebook: <a href="https://www.facebook.com/profile.php?id=100001407512075">Ananta Bhowmik</a> <br><br>
        </p><br>
        		
        		
        		

        <img src="Images/About/sawan.jpg" class="imgRight" /><br><br>
        <h3>Golam Ryan</h3>
        <p align="justify">
           	Hi.......I am Golam Ryan, student of Daffodil International University.<br><br>
           	If case of any query please feel free to contact me : 01627166428 <br>
        	Mail me: <a href="mailto:sawan.ryan@diu.edu.bd"? subject="Information & Query">sawan.ryan@diu.edu.bd</a><br>
        	Become a friend on facebook: <a href="https://web.facebook.com/sawan.ryan">Golam Ryan</a> <br><br><br><br><br><br><br>
        </p>				
		</fieldset>
	';
include 'Template.php';
?>
