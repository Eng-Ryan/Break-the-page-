<?php
//Login data for the database. Use this file in all Models
$host = "localhost";
$user = "root";
$passwd = "";
$database = "coffeedb";

?>
