<?php
$title = "Home";
$content = '
        <img src="Images/coffee4.jpg" class="imgLeft" />
        <h3>Coffee with Milk</h3>
        <p align="justify">
            A "BLACK TIE" is a traditional Thai iced tea, which is a spicy
			and sweet mixture of chilled black tea, orange blossom
			water, star anise, crushed tamarind, sugar and condensed
			milk or cream, with a double shot of espresso.
			<br><br>
			Eiskaffee, literally "ice cream coffee", is a popularerman drink consisting of chilled coffee, milk,
        	 vanilla ice cream, and sometimes sugar and/or whipped cream.	
		
		 </p><br>

        <img src="Images/coffee10.jpg" class="imgRight" />
        <h3>Coffee with Alcohol</h3>
        <p align="justify">
            A liqueur coffee, as its name suggests, is a coffee brew
			with a 25 ml shot of liqueur. This brew is usually served
			in a clear, clean, pre-heated, liqueur coffee glass with
			the coffee and cream separated for good visual and taste
			effect. 
			<br><br>
			Irish coffee is coffee combined with whiskey and cream,
			often further sweetened with sugar. Also available as a
			flavor of ice cream.					
			<br><br>		
			Rudesheimer Kaffee is an alcoholic coffee drink from
			Rudesheim in Germany invented in 1957 by Hans Karl
			Adam. It is made with Asbach Uralt brandy with coffee
			and sugar, and is topped with whipped cream.     
			<br><br>
			A Pharisaer (Danish: farisaer), meaning a Pharisee, is an
			alcoholic coffee drink that is popular in the Nordfriesland
			district of Germany. It consists of a mug of black coffee,
			a double shot of rum, and a topping of whipped cream
					
         </p><br><br>

         <img src="Images/coffee6.jpg" class="imgLeft" />
         <h3>Espresso with Milk</h3>
         <p align="justify">
            Flat white is an espresso with a similar proportion of coffee to milk as a latte and a cappuccino, 
            the main difference being the texture of the milk and (in some regions) the number of espresso shots.
			The drink originated in Australia in the early 1980s as an alternative to the frothier cappuccino.
			<br><br>
			 "Latte macchiato" literally means stained milk. This refers
			to the method of preparation, wherein the milk gets
			"stained" by the addition of espresso.
			<br><br>
			 A "CORTADO" (also known as "pingo" or "garoto") is an
			espresso "cut" rom the Spanish and Portuguese cortar)
			with a small amount of warm milk to reduce the acidity.
			The ratio of milk to coffee is between 1:1 to 1:2, and the
			milk is added after the espresso.

         </p>';
include 'Template.php';
?>
