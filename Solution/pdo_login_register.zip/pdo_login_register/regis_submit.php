<?php
include "connection.php";
extract($_POST);
if(isset($submit))
{
	//inserting data use query function
	/*$img=$_FILES['img']['name'];
	move_uploaded_file($_FILES['img']['tmp_name'],"img/".$img);
	//$pass= password_hash($p,PASSWORD_DEFAULT);
	$row=$conn->query("insert into regis values ('', '$n', '$e', '$nm', '$p', '$img')");*/
	$stmt=$conn->query("insert into regis (name, email, mob, pass) values (':n', ':e', ':nm', ':p')");

	//$stmt->bindParam(':email', $email);
	$stmt->bindParam(':n', $name);
	$stmt->bindParam(':e', $email); 
	$stmt->bindParam(':nm', $mob);
	$stmt->bindParam(':p', $pass);

	if($stmt->rowCount()>0)
	{
		echo "registration successfull";

		echo "<form action='index.php' align='right'>
					<button>GO BACK</button>
				</form>";

	}
	else
	{
		echo "not registered";
	}
}

?>