<?php
include "connection.php";
//$_SESSION['email'];
if (isset($_SESSION['email'])) {
				
				$query="select * from regis";
				$data= $conn->query($query);

				echo '<table width="70%" border="1" cellpadding="5" cellspacing="5">
				<tr>
					<th>id</th>
					<th>name</th>
					<th>email</th>
					<th>mob</th>
					<th>img</th>
				</tr>';

				foreach($data as $row)
				{
					echo '<tr>
					<td>'.$row["id"].'</td>
					<td>'.$row["name"].'</td>
					<td>'.$row["email"].'</td>
					<td>'.$row["mob"].'</td>
					<td>'.$row["img"].'</td>

					</tr>';
				}

				echo '</table>';


				}else {
					("location: index.php");
				}

				echo "<form action='profile.php' align='right'>
					<button>profile</button>
				</form>";

				echo "<form action='logout.php' align='right'>
					<button>LOG OUT</button>
				</form>";


?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

</body>
</html>