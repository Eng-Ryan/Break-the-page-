<?php

?>



<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
	<meta name="veiwport" content="width=device-width,initial-scale=1">
	<title>LOGIN AND REG</title>

</head>
<body>
	<center><h1><u>PROJECT ON:</u> SQL INJECTION </h1></center>
	<div id="login_conatiner">
		<br>
			<center>
				<form method="post" action="login_submit.php">
					<h2>Login Form</h2>
					<br>
					<br>
					<input type="email" name="e" placeholder="Enter Your Email"/><br><br>
					<input type="password" name="p" placeholder="Enter Your Password" /><br><br><br>
					<input type="submit" name="login" value="Submit"/>
				</form>
			</center>
		<br>
		<br>
		<br>
	</div>
	<div id="register_container">

		<br>
		<br>
		<center>
			<form method="post" enctype="multipart/form-data" action="regis_submit.php">
				<h2>Registration Form</h2>
				<br>

				<br>

				<input type="text" name="n" placeholder="Enter Your name"/><br><br>
				<input type="email" name="e" placeholder="Enter Your Email" /><br><br>
				<input type="number" name="nm" placeholder="Enter Your Number"/><br><br>
				<input type="password" name="p" placeholder="Enter Your Password"/><br><br>
				Uploade your image&emsp;<input type="file" name="img" "/><br><br>
				<input type="submit" name="submit" value="Submit"/>
				</form>
		</center>
		<br>
		<br>
	</divN>
</body>
</html>