<?php
include "connection.php";
//$_SESSION['email'];
$e=$_SESSION['email'];
if (isset($_SESSION['email'])) {
				//$conn->prepare("select * from regis where email=:email");
				$statement = $conn->prepare("select * from regis where email= :email");
				$statement->execute(array(
					':email'=> $e
					));

				echo '<table width="70%" border="1" cellpadding="5" cellspacing="5">
				<tr>
					<th>id</th>
					<th>name</th>
					<th>email</th>
					<th>mob</th>
					<th>img</th>
				</tr>';

				foreach($statement as $row)
				{
					echo '<tr>
					<td>'.$row["id"].'</td>
					<td>'.$row["name"].'</td>
					<td>'.$row["email"].'</td>
					<td>'.$row["mob"].'</td>
					<td>'.$row["img"].'</td>

					</tr>';
				}

				echo '</table>';


				}else {
					("location: index.php");
				}

				echo "<form action='home.php' align='right'>
					<button>GO BACK</button>
				</form>";

				echo "<form action='logout.php' align='right'>
					<button>LOG OUT</button>
				</form>";


?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

</body>
</html>